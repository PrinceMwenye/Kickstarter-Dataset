/* Also check year, check null values */


SELECT AVG(goal), Outcome, Currencies.Name AS Currency FROM 
(SELECT c.Goal, c.Backers, c.Outcome, m.Name FROM Campaign c
LEFT JOIN Currency m
ON m.id = c.currency_id) AS Currencies
WHERE Outcome IN ('Successful', 'failed') 
AND Currencies.Name = 'USD'
GROUP BY Outcome, Currency
ORDER BY 1 DESC                        /*   USD$101653 average for failed vs USD$9975.66   */

SELECT id FROM currency c
WHERE c.name =  'USD'					/* Currency Id for USD = 2  */

SELECT AVG(Duration), Outcome FROM
(SELECT Outcome, DATEDIFF(Deadline, Launched) As Duration 
FROM Campaign) AS Duration_t
WHERE Outcome IN ('Successful', 'failed') 
GROUP BY Outcome                              /*35 days for failed, 32 succesful */

SELECT total_goal, c.name FROM
(SELECT SUM(goal) AS total_goal, country_id, Outcome
FROM campaign
WHERE Outcome = 'successful'
GROUP BY country_id, Outcome
ORDER BY 1 DESC
LIMIT  3) AS goal_t
LEFT JOIN Country c
ON goal_t.country_id = c.id                        /* US, GB, and AU top countries */
													/* assume currency is respective to country raised in
                                                    might be different if converted to same currency */
                                 
SELECT SUM(Backers), AVG(Duration), Categories_A.Name FROM
(SELECT * FROM 
(SELECT c.Backers, c.Sub_category_id, DATEDIFF(Deadline, Launched) As Duration,  s.Category_id FROM campaign  c   
INNER JOIN sub_category s
ON c.sub_category_id =  s.id
WHERE Outcome = 'successful')  AS Categories
INNER JOIN category ca
ON Categories.category_id =  ca.id) AS Categories_A
GROUP BY Categories_A.Name
ORDER BY 1 DESC
LIMIT 5      /* Games, Technology, Design  are top backed, change ORDER BY to ASC to get worst 3 which are Dance, journalism and Crafts
			Average duration for top 32.3 games, 35.2 tech, 34.6 design, for bottom 32.3 dance, 35.3 journalism, 31.7 crafts */
            
SELECT SUM(Goal),  Categories_A.Name FROM
(SELECT * FROM 
(SELECT c.Goal, c.Sub_category_id, c.Outcome, c.Currency_id,  s.Category_id FROM campaign  c   
INNER JOIN sub_category s
ON c.sub_category_id =  s.id
WHERE Outcome = 'successful' AND Currency_id = 2)  AS Categories
INNER JOIN category ca
ON Categories.category_id =  ca.id) AS Categories_A
GROUP BY Categories_A.Name
ORDER BY 1 DESC
LIMIT 3                                   /* Film&Video, Tech, Design have most amount
											Crafts, Journalism, Dance least amount*
                                            The worst backed have the least amount raised, not different,
                                            Film has less backs but more money than Games, 10 859 889.5 > 4709858
                                            WHY?  */ 


SELECT id FROM sub_category
WHERE category_id = 7
														 /*7 is category_id for boardgames*/ 
SELECT  c.Name, MAX(Goal), c.Backers, c.Outcome, c.Currency_id FROM Campaign c
WHERE c.sub_category_id  IN  (13,14,44,66,70, 113,122,134)
AND Outcome = 'successful'
GROUP BY  c.Name  
ORDER BY 2 DESC  								/* $600 000 USD by most successful boardgame comp, 13987 backers! UnderWorld Ascendant  */ 


SELECT Countries.Name, SUM(Backers) FROM
(SELECT c.Country_id, c.Backers, ca.Name FROM campaign c
LEFT JOIN Country ca
ON ca.id = c.country_id) AS countries
GROUP BY countries.Name
ORDER BY 2 DESC									/*US, GB, CA  top number of backers*/

SELECT SUM(Country_goals.Goal), Country_goals.Currency FROM
(SELECT c.Goal, cu.name As Currency FROM campaign c
LEFT JOIN currency  cu
ON c.currency_id = cu.id
WHERE c.Outcome = 'successful') AS Country_goals 
GROUP BY Country_goals.Currency
ORDER BY 1 DESC										/* USD, GBP, EUR */



SELECT AVG(Duration),  Outcome FROM
(SELECT Outcome, Currency_id, DATEDIFF(Deadline, Launched) As Duration 
FROM Campaign) AS Duration_t
WHERE Outcome IN ('Successful') 
AND Currency_id = 2
GROUP BY Outcome     

SELECT c.Name FROM campaign c

SELECT * FROM
(SELECT c.Name,  c.Sub_category_id, c.Country_id, c.Currency_id, c.Launched, c.Deadline, DATEDIFF(c.Deadline, c.Launched) AS Duration,
c.Goal, c.Pledged, c.Backers, c.Outcome, ca.Category_id AS Category_id, ca.Name AS Sub_Category_name  FROM campaign c
LEFT JOIN sub_Category ca
ON c.sub_category_id = ca.id) AS new_table
LEFT JOIN category cat
ON cat.id = new_table.Category_id

SELECT  AVG(Backers) FROM campaign c
WHERE c.sub_category_id  IN  (13,14,44,66,70, 113,122,134)
AND Outcome = 'failed'
AND c.Currency_id = 2

			
            
SELECT  AVG(Backers) FROM campaign c
WHERE c.sub_category_id  IN  (13,14,44,66,70, 113,122,134)
AND Outcome = 'successful'
AND c.Currency_id = 2		
									/*64 backers for failed vs 863 */
  
SELECT  AVG(Backers) FROM campaign c
WHERE c.sub_category_id  IN  (13,14,44,66,70, 113,122,134)
AND c.Currency_id = 2	
AND Outcome  IN ('successful', 'failed')                    /* 426   backers */
  
SELECT AVG(Goal), Outcome FROM campaign 
WHERE sub_category_id  IN  (13,14,44,66,70, 113,122,134)
AND Outcome  IN ('successful', 'failed')
AND Currency_id = 2		 
GROUP BY Outcome                    /* $13893 vs $34885 */ 