# -*- coding: utf-8 -*-
"""
Created on Mon Aug 10 10:22:24 2020

@author: Prince
"""

import pandas as pd
import datetime
import numpy as np
data = pd.read_csv('BS.csv') #From R

#removed 5s campaigns whose names could not be parsed because of quotation
#check cor between backers and goal
data.isna().sum() #no missing values
data = data.drop(['Unnamed: 0', 'X', 'X.1'], axis = 1)


#Cleaning/types
data = data.rename(columns={'name': 'Category'})
data.iloc[:, [-1, -3, -5]] = data.iloc[:, [-1, -3, -5]].astype('category')

#extract day and month of launch, no #time of launch?

#fulldatemaker = lambda i: datetime.datetime.strptime(i, '%m/%d/%Y %H:%M')

#data.iloc[:, [4,5]] = data.iloc[:, [4,5]].applymap(fulldatemaker)


def datemaker_date(d):
    date_1 = '/'.join(str(d).split(' ')[0].split('/'))
    date_1 = datetime.datetime.strptime(date_1, '%m/%d/%Y')
    return datetime.datetime.strftime(date_1, '%a')
    
data['day_of_launch'] = data['Launched'].map(datemaker_date)

def datemaker_month(d):
    month_1 = '/'.join(str(d).split(' ')[0].split('/'))
    month_1 = datetime.datetime.strptime(month_1, '%m/%d/%Y')
    return datetime.datetime.strftime(month_1, '%b')

data['month_of_launch'] = data['Launched'].map(datemaker_month)

data.iloc[:, [-1, -2]] = data.iloc[:, [-1, -2]].astype('category')

x = data.corr()

data['length_of_name'] = [len(i.split()) for i in data.Name] #length of name important?


#special name can help, google ads recommendation; special characters, digits and uppercase letters
   
def special_name(n):
    special = ['$','#','%','@','=','+','/','&','Ɛ','™','©','?','!','¡','*','»','«','=']
    if n.isupper():
        return 'yes'
    if any(i in n for i in special):
        return 'yes'
    if any(i.isupper() for i in n.split()):
        return 'yes'
    if any(i.isdigit() for i in n):
        return 'yes'
    else:
        return 'no'
    
data['special_name'] = data['Name'].map(special_name)
data.special_name.value_counts()
model_data = data[data.Outcome.isin(['successful', 'failed'])]
#Training the model
x = model_data.iloc[:, [6,7,9,14,15,16,17 ] ]
z = model_data.iloc[:, [6,7,9,14,15,16,17 ] ]
y = model_data.iloc[:, 10]



model_data.groupby('Outcome')['Outcome'].count()


from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
ct = ColumnTransformer(transformers=[('encoder', OneHotEncoder(sparse= False), [3,4,5,])], remainder='passthrough')


from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
y = le.fit_transform(y)



x = np.array(ct.fit_transform(x))


dum_df = pd.get_dummies(z)



from sklearn.model_selection import train_test_split
x_test, x_train, y_test, y_train = train_test_split(dum_df,y, test_size = 0.8)



#FEATURE SCALING

#no need to scale, RandomForest Handles scaling very well
'''
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
x_train.iloc[:, 0:4] = sc.fit_transform(x_train.iloc[:, 0:4])
x_test.iloc[:, 0:4] = sc.transform(x_test.iloc[:, 0:4])'''

#models RANDOM FOREST, XGBOOST, BAYES

#RANDOM FOREST

from sklearn.ensemble import RandomForestClassifier
Random_classifier = RandomForestClassifier(n_estimators = 500,
                                           criterion = 'entropy', 
                                           random_state = 0,
                                           max_depth = 25,
                                           min_samples_split = 3)
Random_classifier.fit(x_train, y_train)

# Predicting the Test set results
y_pred1 = Random_classifier.predict(x_test)


from sklearn.metrics import accuracy_score 
Random_accuracy = accuracy_score(y_test, y_pred1)

#new_game is the proposed game we want
new_game = np.array([30,13893,85, 10,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0])
#new game with duration 30, goal $15 000, number of backers, #length of name
#at least 90 Backers would be needed for a goal of $15000
#for average goal of $13893, we need at least 85 backers
new_game = new_game.reshape(1,-1)
Random_classifier.predict(new_game)

#hence, our campaign should be successful

USD = model_data[model_data['Currency_id'] == 2]
USD = USD[USD.Outcome == 'successful']
aall_cat_corr = USD.corr() #0.67 strong relationship
games = USD[USD.Category_id == 7]
games = games[games.Outcome == 'successful']
games_corr = games.corr()  #gaming correlation between goal and backers = 0.55 for successful
 #0.006 for all other categories




'''#NAIVE BAYES
from sklearn.naive_bayes import GaussianNB
Naive_classifier = GaussianNB()
Naive_classifier.fit(x_train, y_train)

# Predicting the Test set results
y_pred2 = Naive_classifier.predict(x_test)

Naive_accuracy = accuracy_score(y_test, y_pred2)

#K - NEAREST
# Training the K-NN model on the Training set
from sklearn.neighbors import KNeighborsClassifier
Knearest_classifier = KNeighborsClassifier(n_neighbors = 150, metric = 'minkowski', p = 2)
Knearest_classifier.fit(x_train, y_train)

# Predicting the Test set results
y_pred3 = Knearest_classifier.predict(x_test)

Knearest_accuracy = accuracy_score(y_test, y_pred3)


#KERNEL SVM
# Training the Kernel SVM model on the Training set
from sklearn.svm import SVC
kernel_classifier = SVC(kernel = 'rbf', random_state = 0)
kernel_classifier.fit(x_train, y_train)

# Predicting the Test set results
y_pred4 = kernel_classifier.predict(x_test)


kernel_accuracy = accuracy_score(y_test, y_pred4)

#kernel has the lowest accuracy of them all. 

#XG-BOOST
# Fitting XGBoost to the Training set
from xgboost import XGBClassifier
xg_classifier = XGBClassifier()
xg_classifier.fit(x_train, y_train)

# Predicting the Test set results
y_pred5 = xg_classifier.predict(x_test)

xg_accuracy = accuracy_score(y_test, y_pred4)'''


#GRID SEARCH
'''from sklearn.model_selection import GridSearchCV
parameters = [{'n_estimators': [500, 550],
               'max_depth': [25, 30],
               'min_samples_split': [3]}]
   
gs = GridSearchCV(estimator = Random_classifier,
                  param_grid = parameters,
                  scoring = 'accuracy',
                  cv = 6,
                  n_jobs = -1)

gs = gs.fit(x_train, y_train)
best_accuracy = gs.best_score_
best_params = gs.best_params_   
print(best_accuracy)'''


# Applying k-Fold Cross Validation
from sklearn.model_selection import cross_val_score
accuracies = cross_val_score(estimator = Random_classifier, X = x_train, y = y_train, cv = 10)
accuracies.mean()
accuracies.std()
#Our model looks great! We will most likely get 84% correct that they will either succeed or fail a campaign
#after the best accuracy lets get feature importances
feature_importances = Random_classifier.feature_importances_
#could be domain expect, help us determin e important variables
#could use it to delete features called dimensionality reduction
    

importances = pd.Series(feature_importances, index = dum_df.columns)
importances = pd.DataFrame(importances, columns = index)  

for i,j in sorted(zip(model_data.columns, feature_importances)):
    print(i,j)
    




    
            
            
            
            
    
        
       
        
    
    



